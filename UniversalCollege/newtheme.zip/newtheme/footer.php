<footer>
        <div class="wrapper_footer">
            <div class="subscribe_section">
                <h3>Stay In The Know!</h3>
                <form id="footerForm" onsubmit="return validate()">
                    <label for="email">Please enter your email to join our mailing list</label>
                    <span id="emailError"></span>
                    <input id="email" type="email" name="email">
                    <button type="submit" id="btnGo">GO</button>
                </form>

                <p>To unsubscribe click <a href="?page=">here <i class="fas fa-angle-right"></i><i class="fas fa-angle-right"></i></a></p>
            </div>

            <div class="footer_sections">
                <section>
                    <h3>Lacus interdum</h3>
                    <ul>
                        <li><a href="">Lorem ipsum dolor</a></li> 
                        <li><a href="">Suspendisse in neque</a></li>
                        <li><a href="">Praesent et eros</a></li>
                        <li><a href="">Lorem ipsum dolor</a></li>
                        <li><a href="">Suspendisse in neque</a></li>
                    </ul>
                </section>
    
                <section>
                    <h3>Lacus interdum</h3>
                    <ul>
                        <li><a href="">Lorem ipsum dolor</a></li> 
                        <li><a href="">Suspendisse in neque</a></li>
                        <li><a href="">Praesent et eros</a></li>
                        <li><a href="">Lorem ipsum dolor</a></li>
                        <li><a href="">Suspendisse in neque</a></li>
                    </ul>
                </section>
    
                <section>
                    <h3>Lacus interdum</h3>
                    <ul>
                        <li><a href="">Lorem ipsum dolor</a></li> 
                        <li><a href="">Suspendisse in neque</a></li>
                        <li><a href="">Praesent et eros</a></li>
                        <li><a href="">Lorem ipsum dolor</a></li>
                        <li><a href="">Suspendisse in neque</a></li>
                    </ul>
                </section>
            </div>
        </div>

        <div class="copyright">
            <span>Copyright © 2013 Domain Name - All Rights Reserved</span>
            <span>Template by OS Templates</span>
        </div>
    </footer>

  

    <?php wp_footer();?>
</body>
</html>