<?php get_header();?>
<div class="hero_slider">
        <div class="slider_wrapper">
            <div class="slider_main">
                <div class="slider_item_main">
                    <span>Cursus penati saccum ut curabitur nulla.</span>
                </div>

                <div class="slider_item_main">
                    <span>Cursus penati saccum ut curabitur nulla.</span>
                </div>

                <div class="slider_item_main">
                    <span>Cursus penati saccum ut curabitur nulla.</span>
                </div>

                <div class="slider_item_main">
                    <span>Cursus penati saccum ut curabitur nulla.</span>
                </div>
            </div>

            <div class="slider">
                <div class="slider_item">
                    <span><a href=""><i class="fas fa-angle-right"></i><i class="fas fa-angle-right"></i> Link Text Goes Here</a></span>
                </div>

                <div class="slider_item">
                    <span><a href=""><i class="fas fa-angle-right"></i><i class="fas fa-angle-right"></i> Link Text Goes Here</a></span>
                </div>

                <div class="slider_item">
                    <span><a href=""><i class="fas fa-angle-right"></i><i class="fas fa-angle-right"></i> Link Text Goes Here</a></span>
                </div>

                <div class="slider_item">
                    <span><a href=""><i class="fas fa-angle-right"></i><i class="fas fa-angle-right"></i> Link Text Goes Here</a></span>
                </div>

                <div class="slider_item">
                    <span><a href=""><i class="fas fa-angle-right"></i><i class="fas fa-angle-right"></i> Link Text Goes Here</a></span>
                </div>

                <div class="slider_item">
                    <span><a href=""><i class="fas fa-angle-right"></i><i class="fas fa-angle-right"></i> Link Text Goes Here</a></span>
                </div>

                <div class="slider_item">
                    <span><a href=""><i class="fas fa-angle-right"></i><i class="fas fa-angle-right"></i> Link Text Goes Here</a></span>
                </div>

                <div class="slider_item">
                    <span><a href=""><i class="fas fa-angle-right"></i><i class="fas fa-angle-right"></i> Link Text Goes Here</a></span>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <main>
            <article>
                <h3>Indonectetus facilis leo nibh</h3>

                <img src="http://localhost/wordpress/wp-content/uploads/2020/07/articleImage.png" alt="Article Image" class="article_image">

                <p>
                    Morbitincidunt maurisque eros molest nunc anteget sed vel lacus mus semper. Anter dumnullam interdum eros dui urna 
                    consequam ac nisl nullam ligula vestassa.

                </p>

                <p> 
                    Condimentumfelis et amet tellent quisquet a leo lacus nec augue accumsan. Sagittislaorem dolor ipsum at urna et 
                    pharetium malesuada nis consectus odio.
                </p>

                <button id="btn_art"> Continue Reading <i class="fas fa-angle-right"></i><i class="fas fa-angle-right"></i></button>
            </article>
            
            <article>
                <h3>Indonectetus facilis leo nibh</h3>

                <img src="http://localhost/wordpress/wp-content/uploads/2020/07/articleImage.png" alt="Article Image" class="article_image">

                <p>
                    Morbitincidunt maurisque eros molest nunc anteget sed vel lacus mus semper. Anter dumnullam interdum eros dui urna 
                    consequam ac nisl nullam ligula vestassa.

                </p>

                <p> 
                    Condimentumfelis et amet tellent quisquet a leo lacus nec augue accumsan. Sagittislaorem dolor ipsum at urna et 
                    pharetium malesuada nis consectus odio.
                </p>

                <button id="btn_art">Continue Reading <i class="fas fa-angle-right"></i><i class="fas fa-angle-right"></i></button>
            </article>
            
            <article>
                <h3>Indonectetus facilis leo nibh</h3>

                <img src="http://localhost/wordpress/wp-content/uploads/2020/07/articleImage.png" alt="Article Image" class="article_image">

                <p>
                    Morbitincidunt maurisque eros molest nunc anteget sed vel lacus mus semper. Anter dumnullam interdum eros dui urna 
                    consequam ac nisl nullam ligula vestassa.

                </p>

                <p> 
                    Condimentumfelis et amet tellent quisquet a leo lacus nec augue accumsan. Sagittislaorem dolor ipsum at urna et 
                    pharetium malesuada nis consectus odio.
                </p>

                <button id="btn_art">Continue Reading <i class="fas fa-angle-right"></i><i class="fas fa-angle-right"></i></button>
            </article>
            
            <article>
                <h3>Indonectetus facilis leo nibh</h3>

                <img src="http://localhost/wordpress/wp-content/uploads/2020/07/articleImage.png" alt="Article Image" class="article_image">
                
                <p>
                    Morbitincidunt maurisque eros molest nunc anteget sed vel lacus mus semper. Anter dumnullam interdum eros dui urna 
                    consequam ac nisl nullam ligula vestassa.

                </p>

                <p> 
                    Condimentumfelis et amet tellent quisquet a leo lacus nec augue accumsan. Sagittislaorem dolor ipsum at urna et 
                    pharetium malesuada nis consectus odio.
                </p>

                <button id="btn_art">Continue Reading <i class="fas fa-angle-right"></i><i class="fas fa-angle-right"></i></button>
            </article>
        </main>

        <?php get_sidebar();?>
    </div>  
<?php get_footer();?>