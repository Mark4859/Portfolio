$(document).ready(function(){
    $('.slider_main').slick({
        arrows: false,
        adaptiveHeight: true,
        speed: 400,
        swipe: true,
        touchThreshold: 10,
        touchMove: true,
        fade: true,
        autoplay: true,
        speed: 1500,
        autoplaySpeed: 5500,
    });
    $('.slider').slick({
        arrows: false,
        adaptiveHeight: true,
        slidesToShow: 4,
        swipe: true,
        touchThreshold: 10,
        touchMove: true,
        variableWidth: true,
        infinite: true,
        touchThreshold: 10,
        waitForAnimate: false,
        slidesToScroll: 2,
    });
});
let i = 1;  
let emailErr = document.getElementById("emailError");   
let emailInp = document.getElementById("email");
function showMenu(){
    i = i + 1;
    let nav = document.getElementById("nav_menu");
    if(i % 2 == 0){
        nav.style.display = "inline";
    }
    else{
        nav.style.display = "none";
    }
}
function validate(){
    var emailPattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var resultEmail = emailPattern.test(emailInp.value);
    if(document.forms['footerForm'].email.value == 0){
        emailErr.style.display = "inline-block";
        emailErr.style.color = "red";
        emailErr.innerHTML = "*Empty field!";
        return false;
    }else if(resultEmail == false){
        emailErr.style.display = "inline-block";
        emailErr.style.color = "#AB4029";
        emailErr.innerHTML = "( *An invalid email addres!)";
        return false; 
    }else{
        return true;
    }
}