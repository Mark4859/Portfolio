<?php 
    add_action('wp_enqueue_scripts', 'style_theme');
    add_action('wp_footer', 'scripts_theme');
    add_action('after_setup_theme', 'registerMenu');

    function registerMenu(){
        register_nav_menu('top', 'Header Menu');
    }
    function style_theme(){
        wp_enqueue_style('style', get_stylesheet_uri());
        wp_enqueue_style('default', get_template_directory_uri() .'/assets/css/default.css');
        wp_enqueue_style('media-queries', get_template_directory_uri() .'/assets/css/media-queries.css');
    }
    
    function scripts_theme(){
        wp_deregister_script( 'jquery-core' );
        wp_register_script( 'jquery-core', '//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js');
        wp_enqueue_script( 'jquery' );
        wp_enqueue_script('slick', get_template_directory_uri() .'/assets/js/slick.min.js');
        wp_enqueue_script('js', get_template_directory_uri() .'/assets/js/script.js');
    }
?>