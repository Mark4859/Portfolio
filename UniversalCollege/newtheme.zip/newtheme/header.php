<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://kit.fontawesome.com/f56d5f2e0f.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <?php wp_head();?>
</head>
<body>
    <header>
        <div class="wrapper_header">
            <div class="header_titles">
                <h1><?php bloginfo('name');?></h1>
                <span>Free PSD Website Template</span>
            </div>

            <div class="header_addition">
                <ul class="header_list">
                    <li><a href="">Libero</a> |</li>
                    <li><a href="">Maecenas</a> |</li>
                    <li><a href="">Mauris</a> |</li>
                    <li><a href="">Suspendisse</a></li>
                </ul>

                <div class="contacts">
                    <span>Tel: xxxxx xxxxxxxxxx |</span>
                    <span>Mail: info@domain.com</span>
                </div>
            </div>
        </div>

        <div class="wrapper_top_bar">
            <div class="bars" onclick="showMenu()"><i class="fas fa-bars"></i></div>
            <nav id="nav_menu">
            <?php wp_nav_menu(array(
                'theme_location'=>'top',
                'container'=>'ul',
                'menu_class'=>'nav_header_list',
                'menu_id'=>null
            ));?>
            </nav>

            <form id="header_form" name="header_form">
                <input type="search" placeholder="Search this website..." id="search">
                <button type="button" id="btn_search">SEARCH</button>
                <span id="search_icon"><i class="fas fa-search"></i></span>
            </form>
        </div>
     
    </header> 
